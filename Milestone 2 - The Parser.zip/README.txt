Assignment: Milestone 2. The Parser

So far, I have created a lexer and parser. The two components have been conected together and function properly with one another. 
The program does not crash or become unstable if the source file contains any kind of lexical errors, and if there are any the parser succesfully flags them where necessary. 

Both the lexer and parser have been tested using the provided JACK source files and are shown to function properly without any issues. 




