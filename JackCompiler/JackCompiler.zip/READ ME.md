# Jack Compiler
Compiles all the .jack files in the current working directory.



## Usage

To compile all .jack files in a specified directory:
- python JackCompiler.py <directoryName>

To compile a specified Jack file:
- python JackCompiler.py <fileName.jack>


